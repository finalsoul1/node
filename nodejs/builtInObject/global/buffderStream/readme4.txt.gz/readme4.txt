저를 writeme3.txt로 보내주세요
